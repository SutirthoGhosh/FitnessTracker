package com.fittrack.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
