# FitTrack - Workout Tracking Application

## Overview

FitTrack is a full-stack fitness tracking application built with React, Express, and PostgreSQL. The application allows users to log workouts, track progress, view workout calendars, and analyze fitness statistics. It features a responsive design with mobile-first navigation, comprehensive workout management capabilities, and a beautiful dark/light theme toggle with smooth animations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Style**: RESTful API with conventional HTTP methods
- **Middleware**: Custom logging, JSON parsing, and error handling
- **Development**: Hot reloading with Vite integration in development mode

### Data Storage Solutions
- **Storage Method**: Browser localStorage for local data persistence
- **Data Format**: JSON serialization for all workout, user, and exercise data
- **Storage Implementation**: LocalStorage class for all data operations
- **Data Persistence**: All data saved locally in browser, no cloud dependencies
- **Privacy**: Complete offline functionality with no external data transmission

## Key Components

### Database Schema
- **Users Table**: Basic user authentication with username/password
- **Workouts Table**: Core workout data including type, exercise, sets, reps, weight, duration, and notes
- **Exercises Table**: Reference data for available exercises with muscle group classifications
- **Supported Workout Types**: Cardio, Strength, Yoga, and Gripper exercises

### Frontend Components
- **Layout System**: Responsive sidebar for desktop, bottom navigation for mobile
- **Theme System**: Dark/light mode toggle with animated transitions and localStorage persistence
- **Workout Management**: Modal-based workout logging with form validation
- **Data Visualization**: Charts for progress tracking using Recharts
- **Calendar View**: Monthly calendar with workout indicators
- **Dashboard**: Overview statistics and quick actions

### API Endpoints
- **GET /api/workouts**: Retrieve user workouts
- **GET /api/workouts/range**: Get workouts within date range
- **POST /api/workouts**: Create new workout entries
- **PUT /api/workouts/:id**: Update existing workouts
- **DELETE /api/workouts/:id**: Remove workout entries
- **GET /api/exercises**: Retrieve exercise library
- **GET /api/stats/**: Various statistics endpoints

## Data Flow

1. **Client Requests**: React components use TanStack Query to fetch data
2. **API Layer**: Express routes handle HTTP requests and validate data
3. **Business Logic**: Storage layer abstracts database operations
4. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
5. **Response Flow**: JSON responses sent back through the middleware chain
6. **State Updates**: TanStack Query updates client state and triggers re-renders

The application uses optimistic updates for better user experience and implements proper error handling throughout the stack.

## Recent Changes (July 2025)

### Dark Mode Implementation
- Added complete dark/light theme system with ThemeProvider context
- Implemented animated theme toggle button with sun/moon icons
- Added theme persistence using localStorage
- Updated all components with dark mode variants using Tailwind CSS
- Enhanced visual transitions with 300ms duration animations
- Positioned theme toggle in both desktop sidebar and mobile header

### Database Integration
- Migrated from in-memory storage to PostgreSQL database
- Implemented DatabaseStorage class with full CRUD operations
- Added 40+ pre-loaded exercises across all workout types
- Database schema automatically synced using Drizzle ORM
- All workout data now persists between sessions

### Mobile App Development
- Added Capacitor integration for native mobile app generation
- Configured Android project structure for APK building
- Implemented mobile-specific features (status bar, splash screen)
- Added mobile platform detection and responsive optimizations
- Created comprehensive build instructions for APK generation
- Maintained single codebase for both web and mobile platforms

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React, React DOM, React Router (Wouter)
- **State Management**: TanStack React Query for server state
- **UI Components**: Extensive Radix UI component library
- **Styling**: Tailwind CSS with PostCSS and Autoprefixer
- **Form Handling**: React Hook Form with Zod validation

### Database and Backend
- **Database**: Neon Database serverless PostgreSQL
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod for runtime type checking and validation
- **Session Management**: Connect PG Simple for PostgreSQL session storage

### Development Tools
- **Build System**: Vite with React plugin and error overlay
- **TypeScript**: Full TypeScript support across the stack
- **Development**: TSX for running TypeScript in development
- **Replit Integration**: Cartographer plugin for Replit environment

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express API integration
- **Hot Reloading**: Full-stack hot reloading for rapid development
- **Environment Variables**: DATABASE_URL required for database connection
- **In-Memory Fallback**: MemStorage class for development without database

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild compiles Express server to `dist/index.js`
- **Static Serving**: Express serves built React app in production
- **Database**: PostgreSQL connection via environment variable

### Build Commands
- **Development**: `npm run dev` - Starts development server with hot reloading
- **Production Build**: `npm run build` - Creates optimized builds for both frontend and backend
- **Database Management**: `npm run db:push` - Applies schema changes to database
- **Type Checking**: `npm run check` - Validates TypeScript across the project

The application is designed to work seamlessly in Replit's environment with proper configuration for both development and production deployments.