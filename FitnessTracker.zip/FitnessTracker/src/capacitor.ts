import { CapacitorConfig } from '@capacitor/cli';
import { registerPlugin } from '@capacitor/core';

// Register Capacitor plugins for mobile features
export const setupCapacitor = () => {
  // Import and register plugins only when running on mobile
  if (typeof window !== 'undefined' && window.Capacitor) {
    // Add any mobile-specific initialization here
    console.log('Running on mobile platform:', window.Capacitor.getPlatform());
  }
};

// Mobile-specific utilities
export const isMobile = () => {
  return typeof window !== 'undefined' && window.Capacitor;
};

export const getPlatform = () => {
  if (typeof window !== 'undefined' && window.Capacitor) {
    return window.Capacitor.getPlatform();
  }
  return 'web';
};