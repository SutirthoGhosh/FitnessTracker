#!/bin/bash

echo "🏋️ Building FitTrack Mobile App..."

# Build the web app
echo "📦 Building web application..."
npm run build

# Sync to mobile project
echo "📱 Syncing to Android project..."
npx cap sync android

echo "✅ Mobile project ready!"
echo ""
echo "📋 Next Steps to Generate APK:"
echo "1. Install Android Studio locally"
echo "2. Run: npx cap open android"
echo "3. In Android Studio: Build > Generate Signed Bundle/APK"
echo "4. Choose APK and build"
echo ""
echo "📄 See mobile-build-instructions.md for detailed instructions"
echo ""
echo "🌐 Current web app is mobile-optimized and works on phones at:"
echo "   $(replit url)"